package data.scripts;

import java.awt.Color;
import java.util.List;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.StarSystemType;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;

import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI.SurveyLevel;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;

public class ColonyStarPlugin extends BaseModPlugin {
    @Override
    public void onNewGame() {	
		SectorAPI sector = Global.getSector();
		StarSystemAPI system = sector.createStarSystem("Laputa");
		
		PlanetAPI star = system.initStar(
			"laputa", 
			"star_yellow", 
			700, 
			-7500, 
			-4500, 
			500); 
		
		SectorEntityToken buoy = system.addCustomEntity("laputa_buoy", // unique id
				 "Laputa Buoy", // name - if null, defaultName from custom_entities.json will be used
				 "nav_buoy", // type of object, defined in custom_entities.json
				 "neutral"); // faction
		buoy.setCircularOrbitPointingDown(star, 40, 2000, 70);
		
		SectorEntityToken relay = system.addCustomEntity("laputa_relay", // unique id
				 "Laputa Relay", // name - if null, defaultName from custom_entities.json will be used
				 "comm_relay", // type of object, defined in custom_entities.json
				 "neutral"); // faction
		relay.setCircularOrbitPointingDown(star, 190, 2000, 70);
		
		SectorEntityToken array = system.addCustomEntity("laputa_array", // unique id
				 "Laputa Array", // name - if null, defaultName from custom_entities.json will be used
				 "sensor_array", // type of object, defined in custom_entities.json
				 "neutral"); // faction
		array.setCircularOrbitPointingDown(star, 220, 2000, 70);
		
		SectorEntityToken laputa_gate = system.addCustomEntity("laputa_gate", // unique id
				 "Laputa Gate", // name - if null, defaultName from custom_entities.json will be used
				 "inactive_gate", // type of object, defined in custom_entities.json
				 null); // faction
		laputa_gate.setCircularOrbit( star, 120, 2000, 70);
		
		PlanetAPI stream = system.addPlanet("stream", star, "Stream", "gas_giant", 230, 350, 5000, 150);
		
		MarketAPI stream_market = Global.getFactory().createMarket("stream_market", stream.getName(), 0);
		stream_market.setPlanetConditionMarketOnly(true); //This "market" only represents planet conditions.
		stream_market.addCondition(Conditions.VERY_HOT); //It's a hot Jupiter so let's make it hot! 
		stream_market.addCondition(Conditions.DENSE_ATMOSPHERE); //It's a gas giant, so let's make it gassy!
		stream_market.addCondition(Conditions.EXTREME_WEATHER);
		stream_market.addCondition(Conditions.HIGH_GRAVITY);
		stream_market.addCondition(Conditions.VOLATILES_PLENTIFUL);
		stream_market.setPrimaryEntity(stream); //Tell the "market" that it's on our planet.
		stream.setMarket(stream_market); //Likewise, tell our planet that it has a "market".
		
			PlanetAPI paradise = system.addPlanet("paradise", stream, "Paradise", "terran", 0, 80, 700, 25);
		
			MarketAPI paradise_market = Global.getFactory().createMarket("paradise_market", paradise.getName(), 0);
			paradise_market.setPlanetConditionMarketOnly(true); //This "market" only represents planet conditions.
			paradise_market.addCondition(Conditions.HABITABLE);
			paradise_market.addCondition(Conditions.MILD_CLIMATE);
			paradise_market.addCondition(Conditions.ORE_ULTRARICH);
			paradise_market.addCondition(Conditions.RARE_ORE_ULTRARICH);
			paradise_market.addCondition(Conditions.ORGANICS_PLENTIFUL);
			paradise_market.addCondition(Conditions.VOLATILES_PLENTIFUL);
			paradise_market.addCondition(Conditions.FARMLAND_BOUNTIFUL);
			paradise_market.addCondition(Conditions.RUINS_VAST);
			paradise_market.setPrimaryEntity(paradise); //Tell the "market" that it's on our planet.
			paradise.setMarket(paradise_market); //Likewise, tell our planet that it has a "market".
		
			PlanetAPI eden = system.addPlanet("eden", stream, "Eden", "terran", 45, 120, 1200, 40);
		
			MarketAPI eden_market = Global.getFactory().createMarket("eden_market", eden.getName(), 0);
			eden_market.setPlanetConditionMarketOnly(true); //This "market" only represents planet conditions.
			eden_market.addCondition(Conditions.HABITABLE);
			eden_market.addCondition(Conditions.MILD_CLIMATE);
			eden_market.addCondition(Conditions.ORE_ULTRARICH);
			eden_market.addCondition(Conditions.RARE_ORE_ULTRARICH);
			eden_market.addCondition(Conditions.ORGANICS_PLENTIFUL);
			eden_market.addCondition(Conditions.VOLATILES_PLENTIFUL);
			eden_market.addCondition(Conditions.FARMLAND_BOUNTIFUL);
			eden_market.addCondition(Conditions.RUINS_VAST);
			eden_market.setPrimaryEntity(eden); //Tell the "market" that it's on our planet.
			eden.setMarket(eden_market); //Likewise, tell our planet that it has a "market".
		
			PlanetAPI heaven = system.addPlanet("heaven", stream, "Heaven", "terran", 190, 100, 1600, 55);
		
			MarketAPI heaven_market = Global.getFactory().createMarket("heaven_market", heaven.getName(), 0);
			heaven_market.setPlanetConditionMarketOnly(true); //This "market" only represents planet conditions.
			heaven_market.addCondition(Conditions.HABITABLE);
			heaven_market.addCondition(Conditions.MILD_CLIMATE);
			heaven_market.addCondition(Conditions.ORE_ULTRARICH);
			heaven_market.addCondition(Conditions.RARE_ORE_ULTRARICH);
			heaven_market.addCondition(Conditions.ORGANICS_PLENTIFUL);
			heaven_market.addCondition(Conditions.VOLATILES_PLENTIFUL);
			heaven_market.addCondition(Conditions.FARMLAND_BOUNTIFUL);
			heaven_market.addCondition(Conditions.RUINS_VAST);
			heaven_market.setPrimaryEntity(heaven); //Tell the "market" that it's on our planet.
			heaven.setMarket(heaven_market); //Likewise, tell our planet that it has a "market".
		
			PlanetAPI elisium = system.addPlanet("elysium", stream, "Elisium", "terran", 240, 110, 2000, 75);
		
			MarketAPI elisium_market = Global.getFactory().createMarket("elisium_market", elisium.getName(), 0);
			elisium_market.setPlanetConditionMarketOnly(true); //This "market" only represents planet conditions.
			elisium_market.addCondition(Conditions.HABITABLE);
			elisium_market.addCondition(Conditions.MILD_CLIMATE);
			elisium_market.addCondition(Conditions.ORE_ULTRARICH);
			elisium_market.addCondition(Conditions.RARE_ORE_ULTRARICH);
			elisium_market.addCondition(Conditions.ORGANICS_PLENTIFUL);
			elisium_market.addCondition(Conditions.VOLATILES_PLENTIFUL);
			elisium_market.addCondition(Conditions.FARMLAND_BOUNTIFUL);
			elisium_market.addCondition(Conditions.RUINS_VAST);
			elisium_market.setPrimaryEntity(elisium); //Tell the "market" that it's on our planet.
			elisium.setMarket(elisium_market); //Likewise, tell our planet that it has a "market".
		
		PlanetAPI chor = system.addPlanet("chor", star, "Chor", "barren", 300, 60, 8000, 250);
		
		MarketAPI chor_market = Global.getFactory().createMarket("chor_market", chor.getName(), 0);
		chor_market.setPlanetConditionMarketOnly(true); //This "market" only represents planet conditions.
		chor_market.addCondition(Conditions.THIN_ATMOSPHERE); //It's a gas giant, so let's make it gassy!
		chor_market.addCondition(Conditions.LOW_GRAVITY);
		chor_market.addCondition(Conditions.ORE_ULTRARICH);
		chor_market.addCondition(Conditions.RARE_ORE_ULTRARICH);
		chor_market.addCondition(Conditions.RUINS_VAST);
		chor_market.setPrimaryEntity(chor); //Tell the "market" that it's on our planet.
		chor.setMarket(chor_market); //Likewise, tell our planet that it has a "market".
		
		PlanetAPI akar = system.addPlanet("akar", star, "Akar", "tundra", 0, 150, 8500, 275);
		
		MarketAPI akar_market = Global.getFactory().createMarket("akar_market", akar.getName(), 0);
		akar_market.setPlanetConditionMarketOnly(true); //This "market" only represents planet conditions.
		akar_market.addCondition(Conditions.HABITABLE); //It's a hot Jupiter so let's make it hot! 
		akar_market.addCondition(Conditions.COLD); //It's a gas giant, so let's make it gassy!
		akar_market.addCondition(Conditions.DECIVILIZED);
		akar_market.addCondition(Conditions.ORE_MODERATE);
		akar_market.addCondition(Conditions.ORGANICS_COMMON);
		akar_market.addCondition(Conditions.VOLATILES_DIFFUSE);
		akar_market.addCondition(Conditions.FARMLAND_POOR);
		akar_market.addCondition(Conditions.RUINS_VAST);
		akar_market.setPrimaryEntity(akar); //Tell the "market" that it's on our planet.
		akar.setMarket(akar_market); //Likewise, tell our planet that it has a "market".
		
		PlanetAPI telt = system.addPlanet("telt", star, "Telt", "barren-bombarded", 130, 130, 9000, 300);
		
		MarketAPI telt_market = Global.getFactory().createMarket("telt_market", telt.getName(), 0);
		telt_market.setPlanetConditionMarketOnly(true); //This "market" only represents planet conditions.
		telt_market.addCondition(Conditions.METEOR_IMPACTS); //It's a hot Jupiter so let's make it hot! 
		telt_market.addCondition(Conditions.NO_ATMOSPHERE); //It's a gas giant, so let's make it gassy!
		telt_market.addCondition(Conditions.ORE_ULTRARICH);
		telt_market.addCondition(Conditions.RARE_ORE_RICH);
		telt_market.addCondition(Conditions.RUINS_VAST);
		telt_market.setPrimaryEntity(telt); //Tell the "market" that it's on our planet.
		telt.setMarket(telt_market); //Likewise, tell our planet that it has a "market".
		
		PlanetAPI glass = system.addPlanet("glass", star, "Glass", "frozen", 70, 170, 9500, 330);
		
		MarketAPI glass_market = Global.getFactory().createMarket("glass_market", glass.getName(), 0);
		glass_market.setPlanetConditionMarketOnly(true); //This "market" only represents planet conditions.
		glass_market.addCondition(Conditions.VERY_COLD); //It's a hot Jupiter so let's make it hot! 
		glass_market.addCondition(Conditions.NO_ATMOSPHERE); //It's a gas giant, so let's make it gassy!
		glass_market.addCondition(Conditions.VOLATILES_PLENTIFUL);
		glass_market.addCondition(Conditions.ORGANICS_COMMON);
		glass_market.addCondition(Conditions.ORE_RICH);
		glass_market.addCondition(Conditions.RARE_ORE_MODERATE);
		glass_market.addCondition(Conditions.RUINS_VAST);
		glass_market.setPrimaryEntity(glass); //Tell the "market" that it's on our planet.
		glass.setMarket(glass_market); //Likewise, tell our planet that it has a "market".
		
		StarSystemGenerator.addOrbitingEntities(
			system, 
			star, 
			StarAge.AVERAGE, //Let's try old system entities this time.
			6, 8, //Let's allow for the possibility of no new entities after Aaarg.
			glass.getCircularOrbitRadius() + 600, //Here we grab Steam's orbit radius to figure out where to start adding from.
			system.getPlanets().size(), //Let's start naming planets based off the number of planets already in this location.
			false); // Again, let's use generic planet names.
		
		system.autogenerateHyperspaceJumpPoints(true, true);
    }
}
